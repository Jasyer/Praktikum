#ifndef _MYTYPES_H_
#define _MYTYPES_H_

#include <stdint.h>

typedef unsigned char byte;
typedef unsigned int word;
typedef uint64_t dword;

#define BYTE1(w) (((w) >> 24) & 0xff)
#define BYTE2(w) (((w) >> 16) & 0xff)
#define BYTE3(w) (((w) >> 8) & 0xff)
#define BYTE4(w) ((w) & 0xff)

#endif