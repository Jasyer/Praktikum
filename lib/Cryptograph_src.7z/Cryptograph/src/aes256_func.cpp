#include "aes256_func.h"

#define SUBWORD(w) (w = (Sbox[BYTE1(w)] << 24) | (Sbox[BYTE2(w)] << 16) | (Sbox[BYTE3(w)] << 8) | Sbox[BYTE4(w)]);
#define INV_SUBWORD(w) (w = (InvSbox[BYTE1(w)] << 24) | (InvSbox[BYTE2(w)] << 16) | (InvSbox[BYTE3(w)] << 8) | InvSbox[BYTE4(w)]);

#define ROTWORD(w) (w = ((w) << 8) & 0xffffff00 | BYTE1(w))

void KeyExpansion(byte *key, word **w) {
	*w = new word[60];	// N_B * (N_R + 1) == 60;
	for (byte i = 0; i < 8; ++i) {	// size(Key) == 32 bytes;
		SET_BYTE1((*w)[i], key[(i << 2) & 0xfc]);
		SET_BYTE2((*w)[i], key[(i << 2) & 0xfc | 0x1]);
		SET_BYTE3((*w)[i], key[(i << 2) & 0xfc | 0x2]);
		SET_BYTE4((*w)[i], key[(i << 2) & 0xfc | 0x3]);
	}
	byte i = 8;	// N_K == 8
	word tmp;
	while (i < 60) {	// N_B * (N_R + 1) == 60;
		tmp = (*w)[i - 1];
		if (i & 0x7) {	// = i mod N_K
			if ((i & 0x7) == 4) {	// i mod N_K == 4
				SUBWORD(tmp);
			}
		} else {
			ROTWORD(tmp);
			SUBWORD(tmp);
			tmp ^= Rcon[(i >> 3) & 0xf];	// i div N_K ( < 0x10 )
		}
		(*w)[i] = (*w)[i - N_K] ^ tmp;
		i++;
	}
}

void InvKeyExpansion(byte *key, word **w) {
	*w = new word[60];	// N_B * (N_R + 1) == 60;
	for (byte i = 0; i < 8; ++i) {	// size(Key) == 32 bytes;
		SET_BYTE1((*w)[i], key[(i << 2) & 0xfc]);
		SET_BYTE2((*w)[i], key[(i << 2) & 0xfc | 0x1]);
		SET_BYTE3((*w)[i], key[(i << 2) & 0xfc | 0x2]);
		SET_BYTE4((*w)[i], key[(i << 2) & 0xfc | 0x3]);
	}
	byte i = 8;	// N_K == 8
	word tmp;
	while (i < 60) {	// N_B * (N_R + 1) == 60;
		tmp = (*w)[i - 1];
		if (i & 0x7) {	// = i mod N_K
			if ((i & 0x7) == 4) {	// i mod N_K == 4
				SUBWORD(tmp);
			}
		} else {
			ROTWORD(tmp);
			SUBWORD(tmp);
			tmp ^= Rcon[(i >> 3) & 0xf];	// i div N_K ( < 0x10 )
		}
		(*w)[i] = (*w)[i - N_K] ^ tmp;
		i++;
	}
	for (byte i = 1; i < 14; ++i) {
		InvMixColumns((*w) + byte((i << 2) & 0xfc));
	}
}

void AddRoundKey(word *state, word *w, byte round) {
	for (byte i = 0; i < 4; ++i) {
		state[i] ^= w[(round << 2) & 0xfe | i];
	}
}

void MixColumns(word *state) {
	byte s1, s2, s3, s4, t;
	for (byte i = 0; i < 4; ++i) {
		s1 = BYTE1(state[i]);
		s2 = BYTE2(state[i]);
		s3 = BYTE3(state[i]);
		s4 = BYTE4(state[i]);
		t = (s1 << 1) ^ (s2 << 1) ^ s2 ^ s3 ^ s4;
		if ((s1 ^ s2) & 0x80) {
			t ^= 0x1b;
		}
		SET_BYTE1(state[i], t);
		t = (s2 << 1) ^ (s3 << 1) ^ s1 ^ s3 ^ s4;
		if ((s2 ^ s3) & 0x80) {
			t ^= 0x1b;
		}
		SET_BYTE2(state[i], t);
		t = (s3 << 1) ^ (s4 << 1) ^ s1 ^ s2 ^ s4;
		if ((s3 ^ s4) & 0x80) {
			t ^= 0x1b;
		}
		SET_BYTE3(state[i], t);
		t = (s4 << 1) ^ (s1 << 1) ^ s1 ^ s2 ^ s3;
		if ((s4 ^ s1) & 0x80) {
			t ^= 0x1b;
		}
		SET_BYTE4(state[i], t);
	}
}

void ShiftRows(word *state) {
	word tmp;
	tmp = state[0] & 0x00ff0000;
	state[0] = state[0] & 0xff00ffff | state[1] & 0x00ff0000;
	state[1] = state[1] & 0xff00ffff | state[2] & 0x00ff0000;
	state[2] = state[2] & 0xff00ffff | state[3] & 0x00ff0000;
	state[3] = state[3] & 0xff00ffff | tmp;
	tmp = state[0] & 0x0000ff00;
	state[0] = state[0] & 0xffff00ff | state[2] & 0x0000ff00;
	state[2] = state[2] & 0xffff00ff | tmp;
	tmp = state[1] & 0x0000ff00;
	state[1] = state[1] & 0xffff00ff | state[3] & 0x0000ff00;
	state[3] = state[3] & 0xffff00ff | tmp;
	tmp = state[3] & 0x000000ff;
	state[3] = state[3] & 0xffffff00 | state[2] & 0x000000ff;
	state[2] = state[2] & 0xffffff00 | state[1] & 0x000000ff;
	state[1] = state[1] & 0xffffff00 | state[0] & 0x000000ff;
	state[0] = state[0] & 0xffffff00 | tmp;
}

void SubBytes(word *state) {
	for (byte i = 0; i < 4; ++i) {
		SUBWORD(state[i]);
	}
}

void Chipher(byte *in, byte *out, word *w) {
	word *state = new word[4];
	for (byte i = 0; i < 4; ++i) {
		SET_BYTE1(state[i], in[(i << 2) & 0xfc]);
		SET_BYTE2(state[i], in[(i << 2) & 0xfc | 0x1]);
		SET_BYTE3(state[i], in[(i << 2) & 0xfc | 0x2]);
		SET_BYTE4(state[i], in[(i << 2) & 0xfc | 0x3]);
	}
	AddRoundKey(state, w, 0);
	for (byte round = 1; round < 14; ++round) {	// 13 == N_R - 1
		SubBytes(state);
		ShiftRows(state);
		MixColumns(state);
		AddRoundKey(state, w, round);
	}
	SubBytes(state);
	ShiftRows(state);
	AddRoundKey(state, w, 14);
	for (byte i = 0; i < 4; ++i) {
		out[(i << 2) & 0xfc] = BYTE1(state[i]);
		out[(i << 2) & 0xfc | 0x1] = BYTE2(state[i]);
		out[(i << 2) & 0xfc | 0x2] = BYTE3(state[i]);
		out[(i << 2) & 0xfc | 0x3] = BYTE4(state[i]);
	}
}

void InvShiftRows(word *state) {
	word tmp;
	tmp = state[3] & 0x00ff0000;
	state[3] = state[3] & 0xff00ffff | state[2] & 0x00ff0000;
	state[2] = state[2] & 0xff00ffff | state[1] & 0x00ff0000;
	state[1] = state[1] & 0xff00ffff | state[0] & 0x00ff0000;
	state[0] = state[0] & 0xff00ffff | tmp;
	tmp = state[0] & 0x0000ff00;
	state[0] = state[0] & 0xffff00ff | state[2] & 0x0000ff00;
	state[2] = state[2] & 0xffff00ff | tmp;
	tmp = state[1] & 0x0000ff00;
	state[1] = state[1] & 0xffff00ff | state[3] & 0x0000ff00;
	state[3] = state[3] & 0xffff00ff | tmp;
	tmp = state[0] & 0x000000ff;
	state[0] = state[0] & 0xffffff00 | state[1] & 0x000000ff;
	state[1] = state[1] & 0xffffff00 | state[2] & 0x000000ff;
	state[2] = state[2] & 0xffffff00 | state[3] & 0x000000ff;
	state[3] = state[3] & 0xffffff00 | tmp;
}

void InvSubBytes(word *state) {
	for (byte i = 0; i < 4; ++i) {
		INV_SUBWORD(state[i]);
	}
}

byte xtime(byte b, char n) {
	byte out;
	for (byte i = 0; i < n; ++i) {
		out = b << 1;
		if (b & 0x80) {
			out ^= 0x1b;
		}
		b = out;
	}
	return out;
}

void InvMixColumns(word *state) {
	byte s1, s2, s3, s4, t, k, k3;
	for (byte i = 0; i < 4; ++i) {
		s1 = BYTE1(state[i]);
		s2 = BYTE2(state[i]);
		s3 = BYTE3(state[i]);
		s4 = BYTE4(state[i]);
		k = s1 ^ s2 ^ s3 ^ s4;
		k3 = xtime(k, 3);
		t = s1 ^ k ^ k3 ^ xtime(s1 ^ s3, 2) ^ xtime(s1 ^ s2, 1);
		SET_BYTE1(state[i], t);
		t = s2 ^ k ^ k3 ^ xtime(s2 ^ s4, 2) ^ xtime(s2 ^ s3, 1);
		SET_BYTE2(state[i], t);
		t = s3 ^ k ^ k3 ^ xtime(s3 ^ s1, 2) ^ xtime(s3 ^ s4, 1);
		SET_BYTE3(state[i], t);
		t = s4 ^ k ^ k3 ^ xtime(s4 ^ s2, 2) ^ xtime(s4 ^ s1, 1);
		SET_BYTE4(state[i], t);
	}
}

void InvChipher (byte *in, byte *out, word *w) {	// EqInvChiper
	word *state = new word[4];
	for (byte i = 0; i < 4; ++i) {
		SET_BYTE1(state[i], in[(i << 2) & 0xfc]);
		SET_BYTE2(state[i], in[(i << 2) & 0xfc | 0x1]);
		SET_BYTE3(state[i], in[(i << 2) & 0xfc | 0x2]);
		SET_BYTE4(state[i], in[(i << 2) & 0xfc | 0x3]);
	}
	AddRoundKey(state, w, 14);
	for (byte round = 13; round > 0; --round) {	// 13 == N_R - 1
		InvSubBytes(state);
		InvShiftRows(state);
		InvMixColumns(state);
		AddRoundKey(state, w, round);
	}
	InvSubBytes(state);
	InvShiftRows(state);
	AddRoundKey(state, w, 0);
	for (byte i = 0; i < 4; ++i) {
		out[(i << 2) & 0xfc] = BYTE1(state[i]);
		out[(i << 2) & 0xfc | 0x1] = BYTE2(state[i]);
		out[(i << 2) & 0xfc | 0x2] = BYTE3(state[i]);
		out[(i << 2) & 0xfc | 0x3] = BYTE4(state[i]);
	}
}