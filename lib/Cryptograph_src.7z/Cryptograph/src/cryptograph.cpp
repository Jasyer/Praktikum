#include "cryptograph.h"
#include <intrin.h>
#include "aes256_func.h"
#include "sha256_func.h"
#include <cstdlib>

struct state
{
    void inc_reseed_counter()
    {
        byte t = reseed_counter[0];
        reseed_counter[0]++;
        for (int i = 1; i < 32 && t > reseed_counter[i - 1]; ++i)
        {
            t = reseed_counter[i];
            reseed_counter[i]++;
        }
    }
    void reset_reseed_counter()
    {
        reseed_counter[0] = 1;
        for (int i = 1; i < 32; ++i)
            reseed_counter[i] = 0;
    }
    byte V[32];
    byte C[32];
    byte reseed_counter[32];
};

int calc_sha256_hash(char *in, int _n, char *out, int *need)
{
    if (out == NULL) {
        *need = 0x20;
        return 0;
    }
    if (in == NULL || _n == 0)
        return -1;
    byte *LastBlocks, NLastBlocks;
    dword n = _n;
    TakeLastBlocks((byte *) in, &LastBlocks, NLastBlocks, n);
    GetChache((byte *) in, LastBlocks, NLastBlocks, (dword) n, (byte *) out);
    return 0;
}

int encrypt_aes256_ecb(char *_in, int _n, char *_key, char *_out, int *_need)
{
    byte *in = (byte *) _in;
    dword n = _n;
    byte *key = (byte *) _key;
    byte *out = (byte *) _out;
    dword *need = (dword *) _need;
    dword n2 = n & 0xfffffff0;
    dword n1 = n2 + 16;
    if (out == NULL)
    {
        *need = n1;
        return 0;
    }
    if (in == 0 || n == 0 || key == 0)
        return -1;
    word *ExpKeys;
    KeyExpansion(key, &ExpKeys);
    for (dword i = 0; i < n2; i += 16)
        Chipher(in + i, out + i, ExpKeys);
    byte *last = new byte[16];
    for (dword j = n2; j < n; ++j)
        last[j - n2] = in[j];
    last[n - n2] = 0x80;
    for (dword j = n + 1; j < n1; ++j)
        last[j - n2] = 0x00;
    Chipher(last, out + n2, ExpKeys);
    delete []last;
    return 0;
}

int encrypt_aes256_cbc(char *_in, int _n, char *_key, char *_out, int *_need, char *_iv, int _iv_len)
{
    byte *in = (byte *) _in;
    dword n = _n;
    byte *key = (byte *) _key;
    byte *out = (byte *) _out;
    dword *need = (dword *) _need;
    byte *iv = (byte *) _iv;
    dword iv_len = _iv_len;

    dword n2 = n & 0xfffffff0;
    dword n1 = n2 + 16;
    if (out == NULL)
    {
        *need = n1;
        return 0;
    }
    if (iv_len != 16 || in == 0 || n == 0 || key == 0 || iv == 0)
        return -1;
    word *ExpKeys;
    KeyExpansion(key, &ExpKeys);
    dword i;
    byte block[16];
    byte *iv_ptr = iv;
    for (int j = 0; j < 16; ++j)
        block[j] = in[j] ^ iv_ptr[j];
    for (i = 0; i < n2; i += 16)
    {
        Chipher(block, out + i, ExpKeys);
        iv_ptr = out + i;
        if (i + 16 < n2)
            for (int j = 0; j < 16; ++j)
                block[j] = iv_ptr[j] ^ in[i + 16 + j];
    }
    byte *last = new byte[16];
    for (dword j = i; j < n; ++j)
        last[j - i] = in[j] ^ iv_ptr[j - i];
    last[n - i] = 0x80 ^ iv_ptr[n - i];
    for (dword j = n + 1; j < n1; ++j)
        last[j - i] = iv_ptr[j - i];

    Chipher(last, out + i, ExpKeys);
    delete []last;
    return 0;
}

int decrypt_aes256_ecb(char *_in, int _n, char *_key, char *_out, int *_need)
{
    byte *in = (byte *) _in;
    dword n = _n;
    byte *key = (byte *) _key;
    byte *out = (byte *) _out;
    dword *need = (dword *) _need;

    if (out == NULL)
    {
        *need = n;
        return 0;
    }
    if (in == 0 || n == 0 || key == 0)
        return -1;
    word *InvExpKeys;
    InvKeyExpansion(key, &InvExpKeys);
    dword i;
    for (i = 0; i < n; i += 16)
        InvChipher(in + i, out + i, InvExpKeys);
    if (need != NULL)
    {
        while (out[n - 1] == 0x00)
            --n;
        *need = n - 1;
    }
    return 0;
}

int decrypt_aes256_cbc(char *_in, int _n, char *_key, char *_out, int *_need, char *_iv, int _iv_len)
{
    byte *in = (byte *) _in;
    dword n = _n;
    byte *key = (byte *) _key;
    byte *out = (byte *) _out;
    dword *need = (dword *) _need;
    byte *iv = (byte *) _iv;
    dword iv_len = _iv_len;

    if (out == NULL)
    {
        *need = n;
        return 0;
    }
    if (iv_len != 16 || in == 0 || n == 0 || key == 0 || iv == 0)
        return -1;
    word *InvExpKeys;
    InvKeyExpansion(key, &InvExpKeys);
    dword i;
    byte *iv_ptr = iv;
    for (i = 0; i < n; i += 16)
    {
        InvChipher(in + i, out + i, InvExpKeys);
        for (int j = 0; j < 16; ++j)
            out[i + j] ^= iv_ptr[j];
        iv_ptr = in + i;
    }
    if (need != NULL)
    {
        while(out[n - 1] == 0x00)
            --n;
        *need = n - 1;
    }
    return 0;
}

int derive_key(char *_z, int _zLen, char *_k, int _kLen, int pAmt, char *_otherInfo, int _otherLen)
{
    byte *z = (byte *) _z;
    dword zLen = _zLen;
    byte *k = (byte *) _k;
    dword kLen = _kLen;
    byte *otherInfo = (byte *) _otherInfo;
    dword otherLen = _otherLen;

    dword hLenD;
    calc_sha256_hash(0, 0, 0, (int *) &hLenD);
    int hLen = hLenD & 0xffffffff;
    int d = (int) kLen / hLen;
    if (kLen % hLen)
        d++;
    int iterLen = int(pAmt + zLen + otherLen);
    byte *s = new byte[d * hLen];
    byte *tmp = new byte[iterLen];
    for (int i = 0; i < zLen; ++i)
        tmp[pAmt + i] = z[i];
    for (int i = 0; i < otherLen; ++i)
        tmp[pAmt + zLen + i] = otherInfo[i];
    byte *hash = new byte[hLen];
    int m;
    for (int i = 0; i < d; ++i)
    {
        m = i;
        for (int j = 0; j < pAmt; ++j)
        {
            tmp[pAmt - 1 - j] = m & 0xff;
            m >>= 8;
        }
        for (int j = 0; j < zLen; ++j)
            tmp[pAmt + j] = z[j];
        calc_sha256_hash((char *) tmp, iterLen, (char *) hash, 0);
        for (int j = 0; j < hLen; ++j)
            s[iterLen * i + j] = hash[j];
    }
    for (int i = 0; i < kLen; ++i)
        k[i] = s[i];
    delete []s;
    delete []tmp;
    delete []hash;
    return 0;
}

/**
      Deterministic Random Bit Generator
      Artem Vedin, 2012.
*/

static state curr_state;

void Get_Entropy(byte *out, int size)
{
    unsigned long long l, tmp;
    int size_l = sizeof(l) << 3;
    for (int i = 0; i < size; ++i)
    {
        out[i] = 0;
        for (int j = 0; j < 8; ++j)
        {
            l = __rdtsc();
            tmp = l;
            for (int k = 0; k < size_l - 1; ++k)
            {
                l >>= 1;
                tmp ^= l;
            }
            out[i] <<= 1;
            out[i] |= tmp & 0x01;
        }
    }
}

void Instantiate_Hash_DRBG()
{
    byte entropy_input[32];
    byte transformed_entropy_input[32];
    byte seed[32], tmp[33];
    Get_Entropy(entropy_input, 32);
    derive_key((char *) entropy_input, 32, (char *) seed, 32);
    calc_sha256_hash((char *) entropy_input, 32, (char *) transformed_entropy_input, 0);
    curr_state.reset_reseed_counter();
    for (int i = 0; i < 32; ++i)
    {
        curr_state.V[i] = seed[i];
        tmp[i + 1] = seed[i];
    }
    tmp[0] = 0x00;
    calc_sha256_hash((char *) tmp, 33, (char *) curr_state.C, 0);
}

void Reseeding_Hash_DRBG()
{
    byte entropy_input[32];
    Get_Entropy(entropy_input, 32);
    byte transformed_entropy_input[32];
    byte seed[32], tmp[33];
    calc_sha256_hash((char *) entropy_input, 32, (char *) transformed_entropy_input, 0);
    byte seed_material[65];
    seed_material[0] = 0;
    for (int i = 0; i < 32; ++i)
    {
        seed_material[i + 1] = curr_state.V[i];
        seed_material[i + 33] = entropy_input[i];
    }
    derive_key((char *) seed_material, 65, (char *) seed, 32);
    for (int i = 0; i < 32; ++i)
    {
        curr_state.V[i] = seed[i];
        tmp[i + 1] = seed[i];
    }
    tmp[0] = 0x00;
    calc_sha256_hash((char *) tmp, 33, (char *) curr_state.C, 0);
}

void add_mod32(byte *sum, byte *adding)
{
    unsigned int tmp = 0;
    for (int i = 31; i >= 0; --i)
    {
        tmp = int(sum[i]) + int(adding[i]) + (tmp >> 8);
        sum[i] = tmp & 0xff;
    }
}

void inc_mod32(byte *sum)
{
    unsigned int tmp = 0x100;
    int i = 31;
    while (i >= 0 && (tmp & 0xff00))
    {
        tmp = int(sum[i]) + (tmp >> 8);
        sum[i] = tmp & 0xff;
        --i;
    }
}

void Hashgen(byte *out, unsigned int size)
{
    unsigned int m = size >> 5, i;
    if (size & 0x1ff)
        m++;
    byte data[32];
    byte *W = new byte[m << 5];
    for (i = 0; i < 32; ++i)
        data[i] = curr_state.V[i];
    for (i = 0; i < m; ++i)
    {
        calc_sha256_hash((char *) data, 32, (char *) W + (i << 5), 0);
        inc_mod32(data);
    }
    for (i = 0; i < size; ++i)
        out[i] = W[i];
    delete []W;
}

void Hash_DRBG(byte *out, unsigned int size)
{
    Reseeding_Hash_DRBG();
    Hashgen(out, size);
    byte tmp[33];
    tmp[0] = 0x03;
    for (int i = 0; i < 32; ++i)
        tmp[i + 1] = curr_state.V[i];
    byte H[32];
    calc_sha256_hash((char *) tmp, 33, (char *) H, 0);
    byte sum[32] = {0};
    add_mod32(sum, curr_state.V);
    add_mod32(sum, H);
    add_mod32(sum, curr_state.C);
    add_mod32(sum, curr_state.reseed_counter);
    for (int i = 0; i < 32; ++i)
        curr_state.V[i] = sum[i];
    curr_state.inc_reseed_counter();
}

int drbg_generate(char *out, int size)
{
    if (out == 0 || size == 0)
        return -1;
    Instantiate_Hash_DRBG();
    Hash_DRBG((byte *) out, size);
    return 0;
}
