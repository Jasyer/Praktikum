#include <string>
#include <iostream>
#include <intrin.h>
#include "drbg_func.h"

state curr_state;

void Get_Entropy(byte *out, int size) {
	unsigned long long l, tmp;
	int size_l = sizeof(l) << 3;
	for (int i = 0; i < size; ++i) {
		out[i] = 0;
		for (int j = 0; j < 8; ++j) {
			l = __rdtsc();
			tmp = l;
			for (int k = 0; k < size_l - 1; ++k) {
				l >>= 1;
				tmp ^= l;
			}
			out[i] <<= 1;
			out[i] |= tmp & 0x01;
		}
	}
}

void Instantiate_Hash_DRBG() {
	byte entropy_input[32];
	byte transformed_entropy_input[32];
	byte seed[32], tmp[33];
	Get_Entropy(entropy_input, 32);
	Derive(entropy_input, 32, seed, 32, 4, 0, 0);
	Hash(entropy_input, 32, transformed_entropy_input, 0);
	curr_state.reset_reseed_counter();
	for (int i = 0; i < 32; ++i) {
		curr_state.V[i] = seed[i];
		tmp[i + 1] = seed[i];
	}
	tmp[0] = 0x00;
	Hash(tmp, 33, curr_state.C, 0);
}

void Reseeding_Hash_DRBG() {
	byte entropy_input[32];
	Get_Entropy(entropy_input, 32);
	byte transformed_entropy_input[32];
	byte seed[32], tmp[33];
	Hash(entropy_input, 32, transformed_entropy_input, 0);
	byte seed_material[65];
	seed_material[0] = 0;
	for (int i = 0; i < 32; ++i) {
		seed_material[i + 1] = curr_state.V[i];
		seed_material[i + 33] = entropy_input[i];
	}
	Derive(seed_material, 65, seed, 32, 4, 0, 0);
	for (int i = 0; i < 32; ++i) {
		curr_state.V[i] = seed[i];
		tmp[i + 1] = seed[i];
	}
	tmp[0] = 0x00;
	Hash(tmp, 33, curr_state.C, 0);
}

void add_mod32(byte *sum, byte *adding) {
	unsigned int tmp = 0;
	for (int i = 31; i >= 0; --i) {
		tmp = int(sum[i]) + int(adding[i]) + (tmp >> 8);
		sum[i] = tmp & 0xff;
	}
}

void inc_mod32(byte *sum) {
	unsigned int tmp = 0x100;
	int i = 31;
	while (i >= 0 && (tmp & 0xff00)) {
		tmp = int(sum[i]) + (tmp >> 8);
		sum[i] = tmp & 0xff;
		--i;
	}
}

void Hashgen(byte *out, unsigned int size) {
	unsigned int m = size >> 5, i;
	if (size & 0x1ff) {
		m++;
	}
	byte data[32];
	byte *W = new byte[m << 5];
	for (i = 0; i < 32; ++i) {
		data[i] = curr_state.V[i];
	}
	for (i = 0; i < m; ++i) {
		Hash(data, 32, W + (i << 5), 0);
		inc_mod32(data);
	}
	for (i = 0; i < size; ++i) {
		out[i] = W[i];
	}
	delete []W;
}

void Hash_DRBG(byte *out, unsigned int size) {
	Reseeding_Hash_DRBG();
	Hashgen(out, size);
	byte tmp[33];
	tmp[0] = 0x03;
	for (int i = 0; i < 32; ++i) {
		tmp[i + 1] = curr_state.V[i];
	}
	byte H[32];
	Hash(tmp, 33, H, 0);
	byte sum[32] = {0};
	add_mod32(sum, curr_state.V);
	add_mod32(sum, H);
	add_mod32(sum, curr_state.C);
	add_mod32(sum, curr_state.reseed_counter);
	for (int i = 0; i < 32; ++i) {
		curr_state.V[i] = sum[i];
	}
	curr_state.inc_reseed_counter();
}