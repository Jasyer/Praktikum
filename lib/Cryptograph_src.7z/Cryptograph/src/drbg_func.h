#ifndef _DRBG_FUNC_H_
#define _DRBG_FUNC_H_

#include <Windows.h>
#include <stdint.h>

typedef unsigned char byte;
typedef uint64_t dword;

typedef void (*HashFunc) (byte *in, dword inlen, byte *out, dword *outlen);
typedef void (*DeriveFunc) (byte *in, dword inlen, byte *out, dword outlen, int pAmt, byte *other, dword len);
typedef void (*EncryptFunc) (byte *in, dword inlen, byte *key, byte *out, dword *outlen);
typedef void (*DecryptFunc) (byte *in, dword inlen, byte *key, byte *out, dword *outlen);

extern EncryptFunc Encrypt;
extern DecryptFunc Decrypt;

struct state {
	void inc_reseed_counter() {
		byte t = reseed_counter[0];
		reseed_counter[0]++;
		for (int i = 1; i < 32 && t > reseed_counter[i - 1]; ++i) {
			t = reseed_counter[i];
			reseed_counter[i]++;
		}
	}
	void reset_reseed_counter() {
		reseed_counter[0] = 1;
		for (int i = 1; i < 32; ++i) {
			reseed_counter[i] = 0;
		}
	}
	byte V[32];
	byte C[32];
	byte reseed_counter[32];
};

extern state curr_state;

void Instantiate_Hash_DRBG();
void Hash_DRBG(byte *out, unsigned int size);

void LoadDlls();
void FreeDlls();

#endif