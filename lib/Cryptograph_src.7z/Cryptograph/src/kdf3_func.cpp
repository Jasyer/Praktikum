#include "kdf3_func.h"
#include "cryptograph.h"

byte *DeriveKey(BYTE *z, int zLen, int kLen, int pAmt, BYTE *otherInfo, int otherLen) {
	DWORD hLenD;
	MyCrypto::calc_sha256_hash(0, 0, 0, &hLenD);
	int hLen = hLenD & 0xffffffff;
	int d = kLen / hLen;
	if (kLen % hLen) {
		d++;
	}
	int iterLen = pAmt + zLen + otherLen;
	BYTE *s = new BYTE[d * iterLen];
	BYTE *tmp = new BYTE[iterLen];
	for (int i = 0; i < zLen; ++i) {
		tmp[pAmt + i] = z[i];
	}
	for (int i = 0; i < otherLen; ++i) {
		tmp[pAmt + zLen + i] = otherInfo[i];
	}
	BYTE *hash = new BYTE[hLen];
	int k;
	for (int i = 0; i < d; ++i) {
		k = i;
		for (int j = 0; j < pAmt; ++j) {
			tmp[pAmt - 1 - j] = k & 0xff;
			k >>= 8;
		}
		for (int j = 0; j < zLen; ++j) {
			tmp[pAmt + j] = z[j];
		}
		MyCrypto::calc_sha256_hash(tmp, iterLen, hash, 0);
		for (int j = 0; j < iterLen; ++j) {
			s[iterLen * i + j] = hash[j];
		}
	}
	return s;
}
