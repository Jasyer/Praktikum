#ifndef _KDF3_FUNC_H_
#define _KDF3_FUNC_H_

#include "MyTypes.h"

byte *DeriveKey(BYTE *SecretString, int Len, int keyLen, int pAmt, BYTE *otherInfo = 0, int otherLen = 0);

#endif
