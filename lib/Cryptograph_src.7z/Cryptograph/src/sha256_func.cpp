#include "sha256_func.h"

void TakeLastBlocks(byte *input, byte **block, byte &n_block, uint64_t &n) {
	word r = n & 0x3f;
	uint64_t n1;
	n_block = 2;
	/*
	if (r < 56) {
		if (n != r) {
			r += 64;
		} else {
			n_block--;
		}
	} 
	*/
	if (r >= 56) {
		n_block = 2;
	} else {
		n_block = 1;
	}
	word razm = n_block << 6;
	*block = new byte[razm];
	// n1 = n - r;
	n1 = n & 0xffffffffffffffc0;
	for (byte i = 0; i < r; ++i) {
		(*block)[i] = input[n1 + i];
	}
	(*block)[r] = 0x80;
	for (byte i = r + 1; i < razm - 8; ++i) {
		(*block)[i] = 0x0;
	}
	uint64_t bits = n << 3;
	(*block)[razm - 8] = (bits >> 56) & 0xff;
	(*block)[razm - 7] = (bits >> 48) & 0xff;
	(*block)[razm - 6] = (bits >> 40) & 0xff;
	(*block)[razm - 5] = (bits >> 32) & 0xff;
	(*block)[razm - 4] = (bits >> 24) & 0xff;
	(*block)[razm - 3] = (bits >> 16) & 0xff;
	(*block)[razm - 2] = (bits >> 8) & 0xff;
	(*block)[razm - 1] = bits & 0xff;
	//n += 64 - (r & 0x3f);
	n = n1 + (n_block << 6);
}

void GetChache(byte *input, byte *last, byte n_last, uint64_t size, byte *output) {
	uint64_t n_blocks = size >> 6;
	word a, b, c, d, e, f, g, h;
	word H[] = {
		0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 
		0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
	};
	word t1, t2;
	word w[64];
	byte *data = input;
	for (uint64_t i = 0; i < n_blocks; ++i) {
		input += (i << 6);
		if (i >= n_blocks - n_last) {
			data = last;
		}
		for (word j = 0; j < 64; j += 4) {
			w[(j >> 2)] = TO_WORD(data[j], data[j + 1], data[j + 2], data[j + 3]);
		}
		for (word j = 16; j < 64; ++j) {
			w[j] = SIGMA1(w[j - 2]) + w[j - 7] + SIGMA0(w[j - 15]) + w[j - 16];
		}
		a = H[0];
		b = H[1];
		c = H[2];
		d = H[3];
		e = H[4];
		f = H[5];
		g = H[6];
		h = H[7];
		for (byte t = 0; t < 64; ++t) {
			t1 = h + SUMMA1(e) + CH(e, f, g) + K[t] + w[t];
			t2 = SUMMA0(a) + MAJ(a, b, c);
			h = g;
			g = f;
			f = e;
			e = d + t1;
			d = c;
			c = b;
			b = a;
			a = t1 + t2;
		}
		H[0] += a;
		H[1] += b;
		H[2] += c;
		H[3] += d;
		H[4] += e;
		H[5] += f;
		H[6] += g;
		H[7] += h;
	}
	for (byte i = 0; i < 8; ++i) {
		for (byte j = 0; j < 4; ++j) {
			output[((i << 2) + j)] = (H[i] >> ((3 - j) << 3)) & 0xff;
		}
	}
}
