#include "longlibrary.h"
#include <QString>

/* ------------ Constructors & Destructor ------------- */

Long::Long()
{
    size = 1;
    data = new quint8(0);
    module = 0;
}
Long::Long(const char *s)
{
    while (s[0] == '0' && s[0] != '\0');
    size = 0;
    while (s[size] != '\0')
        size++;
    if (size == 0)
    {
        size = 1;
        data = new quint8(0);
    }
    else
    {
        data = new quint8[size];
        for (int i = 0; i < size; ++i)
        {
            if (s[i] >= '0' && s[i] <= '9')
                data[size - 1 - i] = s[i] - '0';
            else if (s[i] >= 'a' && s[i] <= 'f')
                data[size - 1 - i] = s[i] - 'a' + 10;
            else
                data[size - 1 - i] = 0;
        }
    }
    module = 0;
}
Long::Long(const QString &s)
{
    size = s.size();
    if (size == 0)
    {
        size = 1;
        data = new quint8(0);
    }
    else
    {
        data = new quint8[size];
        char c;
        for (int i = 0; i < size; ++i)
        {
            c = s[i].toLatin1();
            if (c >= '0' && c <= '9')
                data[size - 1 - i] = c - '0';
            else if (c >= 'a' && c <= 'f')
                data[size - 1 - i] = c - 'a' + 10;
            else
                data[size - 1 - i] = 0;
        }
    }
    module = 0;
}
Long::Long(char *input_data, short int size_of_input_data)
{
    while (size_of_input_data > 0 && (*input_data) == 0)
    {
        input_data++;
        size_of_input_data--;
    }
    if (size_of_input_data == 0)
    { // input number equals zero
        size = 1;
        data = new quint8(0);
    }
    size = size_of_input_data << 1;  // 2x multuplicate (max_int == 0xf)
    if ((input_data[0] & 0xf0) == 0)
        size--;
    data = new quint8[size];
    for (int i = 0; i < size_of_input_data - 1; ++i)
    {
        data[(i << 1)] = input_data[size_of_input_data - 1 - i] & 0x0f;
        data[(i << 1) + 1] = (input_data[size_of_input_data - 1 - i] & 0xf0) >> 4;
    }
    if (size & 0x1)
        data[size - 1] = input_data[0] & 0x0f;
    else
    {
        data[size - 2] = input_data[0] & 0x0f;
        data[size - 1] = (input_data[0] & 0xf0) >> 4;
    }
    module = 0;
}
Long::Long(const Long &l)
{
    size = l.size;
    data = new quint8[size];
    for (quint8 i = 0; i < size; ++i)
        data[i] = l.data[i];
    if (l.module)
        module = new Long(*(l.module));
    else
        module = 0;
}
Long::Long(const unsigned int n)
{
    quint32 mask = 0xf0000000;
    int k = 8;
    int t = n;
    while ((t & mask) == 0 && k > 0)
    {
        mask >>= 4;
        k--;
    }
    if (k == 0)
    {
        size = 1;
        data = new quint8(0);
    }
    else
    {
        size = k;
        data = new quint8[size];
        for (int i = 0; i < size; ++i)
        {
            data[i] = t & 0xf;
            t >>= 4;
        }
    }
    module = 0;
}
Long::~Long()
{
    delete []data;
    if (module)
        delete module;
}

/* ------------ Ariphmetic operations ------------*/

Long Long::operator= (const Long &l)
{
    if (data)
        delete []data;
    size = l.size;
    data = new quint8[size];
    for (quint8 i = 0; i < size; ++i)
        data[i] = l.data[i];
    if (l.module)
        set_module(*(l.module));
    else
        module = 0;
    return *this;
}
Long operator* (const Long &l1, const Long &l2)
{
    const Long &l_min = (l1.size > l2.size) ? l2 : l1;
    const Long &l_max = (l1.size > l2.size) ? l1 : l2;
    quint16 size_max = l_max.size;
    quint16 size_min = l_min.size;

    Long ans;
    ans.setSize(size_max + size_min);
    quint16 sum;
    quint8 r = 0;
    for (quint16 j = 0; j < size_min; ++j)
    {
        for (quint16 i = 0; i < size_max; ++i)
        {
            sum = ans[i + j] + l_max[i] * l_min[j] + r;
            ans[i + j] = sum & Long::max_int;
            r = sum >> 4;
        }
        if (r > 0)
        {
            ans[size_max + j] = r;
            r = 0;
        }
    }
    if (l1.module)
        ans.module = new Long(*(l1.module));
    else if(l2.module)
        ans.module = new Long(*(l2.module));
    else
        ans.module = 0;
    if (ans.module)
        ans.mod(*(ans.module));
    ans.delete_first_zero_bytes();
    return ans;
}
Long operator+ (const Long &l1, const Long &l2)
{
    const Long &l_min = (l1.size > l2.size) ? l2 : l1;
    const Long &l_max = (l1.size > l2.size) ? l1 : l2;
    quint16 size_max = l_max.size;
    quint16 size_min = l_min.size;
    Long ans;
    ans.setSize(size_max);
    quint8 r = 0;
    quint16 sum;
    for (quint16 i = 0; i < size_min; ++i)
    {
        sum = l_min[i] + l_max[i] + r;
        ans[i] = sum & Long::max_int;
        r = sum >> 4;
    }
    for (quint16 i = size_min; i < size_max; ++i)
    {
        sum = l_max[i] + r;
        ans[i] = sum & Long::max_int;
        r = sum >> 4;
    }
    if (r > 0)
    {
        ans.setSize(ans.size + 1);
        ans[ans.size] = r;
    }
    if (l1.module)
        ans.module = new Long(*(l1.module));
    else if(l2.module)
        ans.module = new Long(*(l2.module));
    else
        ans.module = 0;
    if (ans.module)
        ans.mod(*(ans.module));
    return ans;
}

/* ------------ Logic operations ------------*/

bool Long::operator> (const Long &l) const
{
    Long l1(*this);
    Long l2(l);
    l1.delete_first_zero_bytes();
    l2.delete_first_zero_bytes();
    quint32 l1_bits = l1.countOfBits();
    quint32 l2_bits = l2.countOfBits();
    if (l1_bits == l2_bits)
    {
        for (int i = l1.size - 1; i >= 0; --i)
            if (l1.data[i] < l2.data[i])
                return false;
            else if (l1.data[i] > l2.data[i])
                return true;
        return false;
    }
    else
        return l1_bits > l2_bits;
}
bool Long::operator< (const Long &l) const
{
    Long l1(*this);
    Long l2(l);
    l1.delete_first_zero_bytes();
    l2.delete_first_zero_bytes();
    quint32 l1_bits = l1.countOfBits();
    quint32 l2_bits = l2.countOfBits();
    if (l1_bits == l2_bits)
    {
        for (int i = l1.size - 1; i >= 0; --i)
            if (l1.data[i] > l2.data[i])
                return false;
            else if (l1.data[i] < l2.data[i])
                return true;
        return false;
    }
    else
        return l1_bits < l2_bits;
}
bool Long::operator== (const Long &l) const
{
    Long l1(*this);
    Long l2(l);
    l1.delete_first_zero_bytes();
    l2.delete_first_zero_bytes();
    if (l1.countOfBits() != l2.countOfBits())
        return false;
    for (int i = l1.size - 1; i >= 0; --i)
        if (l1.data[i] != l2.data[i])
            return false;
    return true;
}

/* ------------ Other operations ------------*/

quint8 &Long::operator[] (quint16 i) const
{
    return data[i];
}

/* ------------ Public methods ------------*/

void Long::setSize(quint16 new_size)
{
    if (new_size == size)
        return;
    quint8 *new_data = new quint8[new_size];
    if (new_size > size)
    {
        for (quint16 i = 0; i < size; ++i)
            new_data[i] = data[i];
        for (quint16 i = size; i < new_size; ++i)
            new_data[i] = 0;
    }
    else
    {
        for (quint16 i = 0; i < new_size; ++i)
            new_data[i] = data[i];
    }
    delete []data;
    data = new_data;
    size = new_size;
}
quint16 Long::get_size() const
{
    return size;
}
quint32 Long::countOfBits() const
{
    quint16 i = size - 1;
    quint16 j = 4;
    while (i > 0 && data[i] == 0)
        i--;
    if (data[i] == 0)  // number is zero
        return 0;
    quint8 mask = 0x08;  // first bit of quint4
    while ((data[i] & mask) == 0)
    {
        mask >>= 1;
        j--;
    }
    quint32 count = (i << 2) + j;
    return count;
}
void Long::pow(const Long &l1)
{
    Long l(l1);
    Long a(*this);
    Long b("1");

    quint32 k = l.countOfBits();
    b.set_module(*module);
    for (quint32 i = 0; i < k; ++i)
    {
        if(l.shr())
            b = b * a;
        a = a * a;
    }
    delete []data;
    data = new quint8[b.size];
    for (quint16 i = 0; i < b.size; ++i)
        data[i] = b.data[i];
}
void Long::set_module(const Long &l)
{
    if (module)
        delete module;
    module = new Long(l);
}
void Long::delete_module()
{
    if (module)
    {
        delete module;
        module = 0;
    }
}
int Long::bytes_need() const
{
    int ret = size >> 1;
    if (size & 0x1)
        ret++;
    return ret;
}
void Long::to_char(char *_data, int *data_size)
{
    int _data_size = bytes_need();
    if (_data == 0)
    {
        *data_size = _data_size;
        return;
    }
    for (int i = 0; i < _data_size - 1; ++i)
    {
        _data[_data_size - 1 - i] = data[(i << 1)];
        _data[_data_size - 1 - i] |= data[(i << 1) + 1] << 4;
    }
    if (size & 0x1)
        _data[0] = data[size - 1];
    else
        _data[0] = (data[size - 1] << 4) | data[size - 2];
}
QString Long::toString() const
{
    QString str;
    int k = size - 1;
    while (k >= 0 && data[k] == 0)
        k--;
    if (k < 0)
        return QString("0");
    for (int i = k; i >= 0; --i)
    {
        if (data[i] >= 0 && data[i] <= 9)
            str += (char) data[i] + '0';
        else if (data[i] >= 0xa && data[i] <= 0xf)
            str += (char) data[i] + 'a' - 0xa;
        else
            str += '0';
    }
    return str;
}

/* ------------ Private methods ------------*/

void Long::mod(const Long &_long)
{
    Long l(_long);
    l.delete_first_zero_bytes();
    delete_first_zero_bytes();
    quint16 bytes = l.size;
    Long dev;
    while (!((*this) < l))
    {
        dev = Long::first_bytes_of((*this), bytes);
        if (dev < l)
            dev = Long::first_bytes_of((*this), bytes + 1);
        sub(devide_mini(dev, l));
    }
}
void Long::delete_first_zero_bytes()
{
    quint16 i = size - 1;
    while (i > 0 && data[i] == 0)
        --i;
    if (i < size - 1)
        setSize(i + 1);
}
bool Long::sub(const Long &l)
{
    if (operator<(l))
        return false;
    quint8 r = 0;
    quint16 l_size = l.size;
    quint16 delta = size - l_size;
    if (first_bytes_of((*this), l_size) < l)
        delta--;
    for (quint16 i = 0; i < l_size; ++i)
    {
        if (data[i + delta] < l.data[i] + r)
        {
            data[i + delta] = (quint8) data[i + delta] + (0x10 - l.data[i]) - r;
            r = 1;
        }
        else
        {
            data[i + delta] = (quint8) data[i + delta] - l.data[i] - r;
            r = 0;
        }
    }
    if (r != 0)
        data[delta + l_size]--;
    delete_first_zero_bytes();
    return true;
}
bool Long::shr()
{
    quint8 ret;
    ret = data[0] & 0x1;
    for (quint16 i = 0; i < size - 1; ++i)
    {
        data[i] >>= 1;
        data[i] |= (data[i + 1] & 0x1) << 3;
    }
    data[size - 1] >>= 1;
    return (ret == 1);
}
Long multiplicate_mini(const Long &l, quint8 num)
{
    quint8 r = 0;
    Long ans(l);
    ans.delete_first_zero_bytes();
    quint16 len = ans.size;
    quint8 sum;
    for (quint16 i = 0; i < len; ++i)
    {
        sum = ans[i] * num + r;
        ans[i] = sum & 0xf;
        r = (sum >> 4) & 0xf;
    }
    if (r > 0)
    {
        quint16 tmp = ans.get_size();
        ans.setSize(tmp + 1);
        ans[tmp] = r;
    }
    return ans;
}
Long devide_mini(const Long &l1, const Long &l2)
{
    if (l1 == l2)
        return l1;
    quint8 a = 0x0;
    quint8 b = 0xf;
    quint8 c;
    Long l;
    while (a != b && a + 1 != b)
    {
        c = (b + a) >> 1;
        l = multiplicate_mini(l2, c);
        if (l1 > l)
            a = c;
        else
            b = c;
    }
    return multiplicate_mini(l2, a);
}

/* ------------ Static methods ------------*/

Long Long::first_bytes_of(const Long &l, quint16 bytes)
{
    if (bytes > l.size)
        bytes = l.size;
    Long ans;
    ans.size = bytes;
    ans.data = new quint8[ans.size];
    quint16 delta = l.size - ans.size;
    for (quint16 i = 0; i < ans.size; ++i)
        ans.data[i] = l.data[delta + i];
    ans.module = 0;
    return ans;
}
